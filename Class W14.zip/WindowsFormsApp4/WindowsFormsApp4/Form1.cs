﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Common;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable dtteamhome = new DataTable();
        DataTable dtteamaway = new DataTable();
        DataTable dtmatch = new DataTable();
        DataTable dtplayer = new DataTable();

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.Columns.Add("Team", "Team");
            dataGridView1.Columns.Add("Player", "Player");
            dataGridView1.Columns.Add("Type", "Type");

            sqlConnect = new MySqlConnection(
                $"server=localhost;" +  
                $"uid=root;" +
                $"pwd=isbmantap;" + 
                $"database=premier_league"); 
            sqlConnect.Open();
            sqlConnect.Close();

            //team home
            string team = "select distinct team_name \r\nfrom `match` m\r\njoin team t\r\non t.team_id = m.team_home";
            sqlCommand = new MySqlCommand(team, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtteamhome);

            for (int i = 0; i < dtteamhome.Rows.Count; i++)
            {
                cb_teamhome.Items.Add(dtteamhome.Rows[i][0].ToString());
            }

            //team away
            string team2 = "select distinct team_name \r\nfrom `match` m\r\njoin team t\r\non t.team_id = m.team_away";
            sqlCommand = new MySqlCommand(team2, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtteamaway);

            for (int i = 0; i < dtteamaway.Rows.Count; i++)
            {
                cb_teamaway.Items.Add(dtteamaway.Rows[i][0].ToString());
            }

            string sql= $"select year(match_date) as `Year` , count(m.match_id)\r\nfrom `match` m\r\njoin team t\r\non m.team_home = t.team_id\r\njoin team t2\r\non m.team_away = t2.team_id where t.team_name = '{cb_teamhome.Text}' and t2.team_name = '{cb_teamaway.Text}' group by 1;";
            sqlCommand = new MySqlCommand(sql, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtmatch);

        }

        private void cb_teamhome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_teamaway.Text == cb_teamhome.Text && cb_teamhome.Text != "" && cb_teamaway.Text != "")
            {
                MessageBox.Show("SAME TEAM!");
                cb_teamaway.Text = "";
                cb_teamhome.Text = "";
            }

            if (cb_teamhome.Text != "" && cb_teamaway.Text != "")
            {
                string sql = $"select year(match_date) as `Year` , count(m.match_id)\r\nfrom `match` m\r\njoin team t\r\non m.team_home = t.team_id\r\njoin team t2\r\non m.team_away = t2.team_id where t.team_name = '{cb_teamhome.Text}' and t2.team_name = '{cb_teamaway.Text}' group by 1;";
                sqlCommand = new MySqlCommand(sql, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtmatch);
                int length = 4;
                int number = Convert.ToInt32(dtmatch.Rows[0][1]);
                string urutan = number.ToString("D" + length);
                tb_matchid.Text = dtmatch.Rows[0][0].ToString() + urutan;

                //TEAM
                cb_team.Items.Add(cb_teamhome.Text);
                cb_team.Items.Add(cb_teamaway.Text);
                
            }
           
        }

        private void cb_teamaway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_teamaway.Text == cb_teamhome.Text && cb_teamhome.Text != "" && cb_teamaway.Text != "")
            {
                MessageBox.Show("SAME TEAM!");
                cb_teamaway.Text = "";
                cb_teamhome.Text = "";
            }

            if (cb_teamhome.Text != "" && cb_teamaway.Text != "")
            {
                string sql = $"select year(match_date) as `Year` , count(m.match_id)\r\nfrom `match` m\r\njoin team t\r\non m.team_home = t.team_id\r\njoin team t2\r\non m.team_away = t2.team_id where t.team_name = '{cb_teamhome.Text}' and t2.team_name = '{cb_teamaway.Text}' group by 1;";
                sqlCommand = new MySqlCommand(sql, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtmatch);
                int length = 4;
                int number = Convert.ToInt32(dtmatch.Rows[0][1]);
                string urutan = number.ToString("D" + length);
                tb_matchid.Text = dtmatch.Rows[0][0].ToString() + urutan;

                //TEAM
                cb_team.Items.Add(cb_teamhome.Text);
                cb_team.Items.Add(cb_teamaway.Text);

            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            
            dataGridView1.Rows.Add(cb_team.Text , cb_player.Text , cb_type.Text);
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            //PLAYER
            string sql2 = $"select player_name \r\nfrom player p \r\njoin team t\r\non p.team_id = t.team_id\r\nwhere team_name = '{cb_team.Text}';";
            sqlCommand = new MySqlCommand(sql2, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtplayer);
            for (int i = 0; i < dtplayer.Rows.Count; i++)
            {
                cb_player.Items.Add(dtplayer.Rows[i][0].ToString());
            }
            //TYPE
            cb_type.Items.Add("GO");
            cb_type.Items.Add("GP");
            cb_type.Items.Add("GW");
            cb_type.Items.Add("CR");
            cb_type.Items.Add("CY");
            cb_type.Items.Add("PM");
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView1.SelectedRows)
            {
                dataGridView1.Rows.RemoveAt(row.Index);
            }
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            string sql2 = $"insert into match values\r\n({tb_matchid.Text}, {datetime.Text}, {cb_teamhome.Text}, {cb_teamaway.Text}, goal_home, goal_away);";
            sqlCommand = new MySqlCommand(sql2, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            MessageBox.Show("Done");
        }

        private void datetime_ValueChanged(object sender, EventArgs e)
        {
            //14 februari 2016

            //DateTime dt  = DateTime.TryParse(14/02/2016);
            //MessageBox.Show(dt.ToString());

            //if (datetime.Value < 02/14/2016)

            var fixedDate = new DateTime(2016, 2, 16);
            if (datetime.Value < fixedDate)
            {
                MessageBox.Show("Date can't be less than 14 Februari 2016");
            }


        }
    }
}
